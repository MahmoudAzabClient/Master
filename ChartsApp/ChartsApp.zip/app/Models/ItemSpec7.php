<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PsHeader extends Model
{
    protected $table = "item_spec7";
    protected $guarded = [];
    public $timestamps = true;
}
