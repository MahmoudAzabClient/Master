<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PsItemSpec7 extends Model
{
    protected $table = "PsItemSpec7";
    protected $guarded = [];
    public $timestamps = true;
}
