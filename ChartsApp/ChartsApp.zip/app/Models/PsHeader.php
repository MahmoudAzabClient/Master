<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PsHeader extends Model
{
    protected $table = "PsHeader";
    protected $guarded = [];
    public $timestamps = true;
}
