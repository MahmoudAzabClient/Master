<?php

namespace App\App\Models;

use Illuminate\Database\Eloquent\Model;

class PsHeader extends Model
{
    protected $table = 'psheader';
    protected $guarded = [];
    public $timestamps = true;

}
