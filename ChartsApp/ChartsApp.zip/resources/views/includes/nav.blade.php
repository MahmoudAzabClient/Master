<div class="col mg-t-20">
    <ul>
    <li>
    <a href="{{ route('home') }}"><button class="btn btn-primary">مبيعات الفروع اجمالى</button> </a>
    </li>
    &nbsp;&nbsp;
    <li>
    <a href="{{  route('home2')}}"><button class="btn btn-primary"> مبيعات الاقسام تفصيلى</button></a>
    </li>
    &nbsp;&nbsp;
    <li>
    <a href="{{  route('home3')}}"><button class="btn btn-primary">تحليل مبيعات الفروع </button></a>
    &nbsp;&nbsp;
    <ul>
</div>